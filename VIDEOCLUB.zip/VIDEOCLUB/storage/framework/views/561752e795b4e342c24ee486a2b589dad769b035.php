<?php $__env->startSection('content'); ?>
<style>
    img{
        position: absolute;
        width: 500px;
        left: 30%;
        height:500px;
                
    }
</style>

<div class="md:w-4/12">
    <img class="object-contain h-99  background-size background-adjunto" src="<?php echo e(asset('img/pelis10.jpeg')); ?>" alt="">
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stephanie/web/my_example_app1/resources/views/home.blade.php ENDPATH**/ ?>